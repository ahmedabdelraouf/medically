<?php


namespace App\Http\Resources;


use Illuminate\Http\Resources\Json\JsonResource;

Abstract class AbstractJsonResource extends JsonResource
{

}
