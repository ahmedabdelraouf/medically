<?php

return [
    "price_confirmed_successfully"=>" تم تأكيد السعر من قبل طالب الخدمة ",
    "request_cancelled_successfully"=>"تم إلغاء الطلب من قبل مقدم الخدمة",
    "request_cancelled_by_user"=>"تم إلغاء الطلب من قبل طالب الخدمة",
    "request_cancelled_by_service_provicer"=>"تم الغاء الطلب بواسطة مزود الخدمة",
    "service_marked_as_finished_by_provider"=>"تم انهاء الطلب بنجاح بواسطة مزود الخدمة",
    "user_choosed_you_for_request_contact"=>"تم اختيارك من قبل طالب خدمة وسيتم التواصل معك",
    "request_price_updated"=>"تم تحديث سعر الخدمة",
    "user_will_contact_you_for_his_request"=>"سيقوم طالب خدمة بالتواصل معك للطلب الخاص به",
    "request_finished_by_provider"=>"تم إنهاء الطلب من قبل مقدم الخدمة",
];
