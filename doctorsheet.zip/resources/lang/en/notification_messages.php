<?php

return [
    "price_confirmed_successfully"=>"Request price confirmed successfully",
    "request_cancelled_successfully"=>"Request cancelled successfully",
    "request_cancelled_by_user"=>"Request cancelled by user",
    "request_cancelled_by_service_provicer"=>"Request cancelled by service provider",
    "service_marked_as_finished_by_provider"=>"Request marked as finished by provider",
    "user_choosed_you_for_request_contact"=>"User choosed you for request contact",
    "request_price_updated"=>"Request price updated",
    "user_will_contact_you_for_his_request"=>"user will contact you for his request",
];
