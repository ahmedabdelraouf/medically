<?php

namespace Dev\Application\Utility;


class Currency
{
    const SAR = 'SAR';
}