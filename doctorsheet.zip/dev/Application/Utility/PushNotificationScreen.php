<?php


namespace Dev\Application\Utility;


class PushNotificationScreen
{
    const DefaultScreen = '/';
    const profile = "profile";
    const serviceRequest = "serviceRequest";
}
