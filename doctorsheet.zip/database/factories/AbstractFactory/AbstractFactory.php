<?php


namespace Database\Factories\AbstractFactory;


class AbstractFactory
{

}
